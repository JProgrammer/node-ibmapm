var http=require('http');
var x=require('./x.js');
var port = process.env.VCAP_APP_PORT||process.env.PORT||3000;
http.createServer(function(request,response){
    response.writeHead(200,{'Content-Type': 'text/plain'});
    sleep(300);
    response.end('Hello World\n');
}).listen(port);

function sleep(milliSeconds) {
    x.abc();
     var startTime = new Date().getTime();
     while (new Date().getTime() < startTime + milliSeconds);
}

console.log('Server running at http://localhost:'+port+'/' );

